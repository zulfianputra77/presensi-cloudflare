import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import * as XLSX from 'xlsx';
import { db } from '../db/index.ts';
import {
  users,
  siswa,
  kelas,
  absensi,
  absensiSholat,
  hariLibur,
  konfigurasi,
  logNotifikasiWa,
  sessions
} from '../db/schema.ts';
import { eq, and, sql, desc, asc, inArray, or } from 'drizzle-orm';
import { requireAuth, AuthRequest } from '../middleware/auth.ts';

export const apiRouter = Router();

// Helper: Format date/time
const getTodayStr = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getNowTimeStr = () => {
  const d = new Date();
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
};

const getNowTimeSecStr = () => {
  const d = new Date();
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const seconds = String(d.getSeconds()).padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
};

const calculateTimeDiffMinutes = (startTime: string, endTime: string) => {
  const [h1, m1] = startTime.split(':').map(Number);
  const [h2, m2] = endTime.split(':').map(Number);
  return (h2 * 60 + m2) - (h1 * 60 + m1);
};

// Helper: Get App Config
async function getAppConfigData() {
  const defaultJadwal = {
    "1": { libur: false, masuk_mulai: "06:00", masuk_akhir: "07:15", pulang_mulai: "15:00", pulang_akhir: "17:00" },
    "2": { libur: false, masuk_mulai: "06:00", masuk_akhir: "07:15", pulang_mulai: "15:00", pulang_akhir: "17:00" },
    "3": { libur: false, masuk_mulai: "06:00", masuk_akhir: "07:15", pulang_mulai: "15:00", pulang_akhir: "17:00" },
    "4": { libur: false, masuk_mulai: "06:00", masuk_akhir: "07:15", pulang_mulai: "15:00", pulang_akhir: "17:00" },
    "5": { libur: false, masuk_mulai: "06:00", masuk_akhir: "07:15", pulang_mulai: "15:00", pulang_akhir: "17:00" },
    "6": { libur: false, masuk_mulai: "06:00", masuk_akhir: "07:15", pulang_mulai: "15:00", pulang_akhir: "17:00" },
    "7": { libur: true,  masuk_mulai: "06:00", masuk_akhir: "07:15", pulang_mulai: "15:00", pulang_akhir: "17:00" },
  };

  const rows = await db.select().from(konfigurasi);
  const cfgMap: Record<string, string> = {};
  rows.forEach(r => { cfgMap[r.key] = r.value; });

  let jadwalHarian = defaultJadwal;
  if (cfgMap['jadwal_harian']) {
    try {
      jadwalHarian = JSON.parse(cfgMap['jadwal_harian']);
    } catch (e) {
      jadwalHarian = defaultJadwal;
    }
  }

  return {
    jam_masuk_mulai: cfgMap['jam_masuk_mulai'] || '06:00',
    jam_masuk_akhir: cfgMap['jam_masuk_akhir'] || '07:15',
    jam_pulang_mulai: cfgMap['jam_pulang_mulai'] || '15:00',
    jam_pulang_akhir: cfgMap['jam_pulang_akhir'] || '17:00',
    mode_absen: cfgMap['mode_absen'] || 'masuk_pulang',
    jadwal_harian: jadwalHarian,
  };
}

// ----------------------------------------------------------------------
// 1. AUTENTIKASI & SESSION
// ----------------------------------------------------------------------
apiRouter.post('/auth/login', async (req: Request, res: Response) => {
  try {
    const { username, password, nisn } = req.body;

    let userFound: {
      role: string;
      identifier: string;
      nama: string;
      kelas: string;
    } | null = null;

    if (nisn) {
      const cleanNisn = String(nisn).trim();
      const s = await db.select().from(siswa).where(eq(siswa.nisn, cleanNisn)).limit(1);
      if (s.length === 0) {
        return res.status(404).json({ success: false, message: 'NISN tidak ditemukan di database.' });
      }
      userFound = {
        role: 'siswa',
        identifier: s[0].nisn,
        nama: s[0].nama,
        kelas: s[0].kelas,
      };
    } else if (username && password) {
      const cleanUser = String(username).trim();
      const u = await db.select().from(users).where(eq(users.username, cleanUser)).limit(1);
      if (u.length === 0 || u[0].password !== String(password).trim()) {
        return res.status(401).json({ success: false, message: 'Username atau password salah.' });
      }
      userFound = {
        role: u[0].role,
        identifier: u[0].username,
        nama: u[0].nama || u[0].username,
        kelas: u[0].kelas || '',
      };
    } else {
      return res.status(400).json({ success: false, message: 'Kredensial login tidak lengkap.' });
    }

    const token = crypto.randomUUID();
    const expiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    await db.insert(sessions).values({
      token,
      identifier: userFound.identifier,
      role: userFound.role,
      nama: userFound.nama,
      kelas: userFound.kelas,
      expiresAt: expiry,
    });

    return res.json({
      success: true,
      token,
      role: userFound.role,
      username: userFound.identifier,
      nama: userFound.nama,
      kelas: userFound.kelas,
      nisn: userFound.role === 'siswa' ? userFound.identifier : null,
    });
  } catch (error: any) {
    console.error('Login error:', error);
    return res.status(500).json({ success: false, message: 'Internal Server Error: ' + error.message });
  }
});

apiRouter.get('/auth/me', requireAuth, async (req: AuthRequest, res: Response) => {
  return res.json({ success: true, user: req.user });
});

apiRouter.post('/auth/logout', requireAuth, async (req: AuthRequest, res: Response) => {
  const token = (req.headers.authorization?.split('Bearer ')[1]) || (req.headers['x-session-token'] as string);
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
  }
  return res.json({ success: true, message: 'Logged out successfully' });
});

// ----------------------------------------------------------------------
// 2. SISWA CRUD & LOOKUP
// ----------------------------------------------------------------------
apiRouter.get('/siswa', async (req: Request, res: Response) => {
  try {
    const filterKelas = req.query.filterKelas as string;
    let query = db.select().from(siswa).orderBy(asc(siswa.nama));

    if (filterKelas && filterKelas !== 'SEMUA') {
      const kelasArr = filterKelas.split(',').map(k => k.trim()).filter(Boolean);
      if (kelasArr.length > 0) {
        query = db.select().from(siswa).where(inArray(siswa.kelas, kelasArr)).orderBy(asc(siswa.nama)) as any;
      }
    }

    const list = await query;
    return res.json({ success: true, data: list });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.get('/siswa/cache', async (_req: Request, res: Response) => {
  try {
    const list = await db.select({ nisn: siswa.nisn, nama: siswa.nama, kelas: siswa.kelas }).from(siswa);
    return res.json({ success: true, data: list });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.get('/siswa/:nisn', async (req: Request, res: Response) => {
  try {
    const cleanNisn = String(req.params.nisn).trim();
    const s = await db.select().from(siswa).where(eq(siswa.nisn, cleanNisn)).limit(1);
    if (s.length === 0) return res.status(404).json({ success: false, message: 'Siswa tidak ditemukan' });
    return res.json({ success: true, data: s[0] });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/siswa', requireAuth, async (req: Request, res: Response) => {
  try {
    const data = req.body;
    const cleanNisn = String(data.nisn).replace(/'/g, '').trim();

    const existing = await db.select().from(siswa).where(eq(siswa.nisn, cleanNisn)).limit(1);
    if (existing.length > 0) {
      return res.status(400).json({ success: false, message: 'NISN sudah terdaftar' });
    }

    await db.insert(siswa).values({
      nisn: cleanNisn,
      nama: data.nama,
      jenisKelamin: data.jenisKelamin,
      tanggalLahir: data.tanggalLahir,
      agama: data.agama,
      namaAyah: data.namaAyah,
      namaIbu: data.namaIbu,
      noHp: data.noHp ? String(data.noHp).replace(/'/g, '').trim() : '',
      kelas: data.kelas,
      alamat: data.alamat,
    });

    return res.json({ success: true, message: 'Siswa berhasil ditambahkan' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.put('/siswa/:oldNisn', requireAuth, async (req: Request, res: Response) => {
  try {
    const oldNisn = String(req.params.oldNisn).replace(/'/g, '').trim();
    const data = req.body;
    const newNisn = data.nisn ? String(data.nisn).replace(/'/g, '').trim() : oldNisn;

    const updated = await db.update(siswa)
      .set({
        nisn: newNisn,
        nama: data.nama,
        jenisKelamin: data.jenisKelamin,
        tanggalLahir: data.tanggalLahir,
        agama: data.agama,
        namaAyah: data.namaAyah,
        namaIbu: data.namaIbu,
        noHp: data.noHp ? String(data.noHp).replace(/'/g, '').trim() : '',
        kelas: data.kelas,
        alamat: data.alamat,
      })
      .where(eq(siswa.nisn, oldNisn))
      .returning();

    if (updated.length === 0) {
      return res.status(404).json({ success: false, message: 'Siswa tidak ditemukan' });
    }

    return res.json({ success: true, message: 'Data siswa berhasil diupdate' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.delete('/siswa/:nisn', requireAuth, async (req: Request, res: Response) => {
  try {
    const cleanNisn = String(req.params.nisn).replace(/'/g, '').trim();
    const del = await db.delete(siswa).where(eq(siswa.nisn, cleanNisn)).returning();
    if (del.length === 0) return res.status(404).json({ success: false, message: 'Siswa tidak ditemukan' });
    return res.json({ success: true, message: 'Data siswa berhasil dihapus' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/siswa/bulk-import', requireAuth, async (req: Request, res: Response) => {
  try {
    const items = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'Data import kosong' });
    }

    let added = 0;
    let skipped = 0;

    for (const item of items) {
      const cleanNisn = String(item.nisn || '').replace(/'/g, '').trim();
      if (!cleanNisn || !item.nama) {
        skipped++;
        continue;
      }

      const existing = await db.select().from(siswa).where(eq(siswa.nisn, cleanNisn)).limit(1);
      if (existing.length > 0) {
        skipped++;
        continue;
      }

      await db.insert(siswa).values({
        nisn: cleanNisn,
        nama: String(item.nama).trim(),
        jenisKelamin: item.jenisKelamin || '',
        tanggalLahir: item.tanggalLahir || '',
        agama: item.agama || '',
        namaAyah: item.namaAyah || '',
        namaIbu: item.namaIbu || '',
        noHp: String(item.noHp || '').replace(/'/g, '').trim(),
        kelas: item.kelas || '',
        alamat: item.alamat || '',
      });
      added++;
    }

    return res.json({ success: true, added, skipped, message: `Import selesai. Berhasil: ${added}, Dilewati/Duplikat: ${skipped}` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 3. GURU CRUD
// ----------------------------------------------------------------------
apiRouter.get('/guru', requireAuth, async (_req: Request, res: Response) => {
  try {
    const list = await db.select().from(users).where(eq(users.role, 'guru')).orderBy(asc(users.username));
    return res.json({ success: true, data: list });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/guru', requireAuth, async (req: Request, res: Response) => {
  try {
    const { username, password, kelas: guruKelas } = req.body;
    const cleanUser = String(username).replace(/'/g, '').trim();

    const existing = await db.select().from(users).where(eq(users.username, cleanUser)).limit(1);
    if (existing.length > 0) {
      return res.status(400).json({ success: false, message: 'Username guru sudah terdaftar' });
    }

    await db.insert(users).values({
      username: cleanUser,
      password: String(password).replace(/'/g, '').trim(),
      role: 'guru',
      nama: cleanUser,
      kelas: guruKelas || '',
    });

    return res.json({ success: true, message: 'Guru berhasil ditambahkan' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.put('/guru/:oldUsername', requireAuth, async (req: Request, res: Response) => {
  try {
    const oldUsername = String(req.params.oldUsername).replace(/'/g, '').trim();
    const { username, password, kelas: guruKelas } = req.body;
    const cleanUser = username ? String(username).replace(/'/g, '').trim() : oldUsername;

    await db.update(users)
      .set({
        username: cleanUser,
        password: String(password).replace(/'/g, '').trim(),
        kelas: guruKelas || '',
      })
      .where(and(eq(users.username, oldUsername), eq(users.role, 'guru')));

    return res.json({ success: true, message: 'Data guru berhasil diupdate' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.delete('/guru/:username', requireAuth, async (req: Request, res: Response) => {
  try {
    const cleanUser = String(req.params.username).replace(/'/g, '').trim();
    await db.delete(users).where(and(eq(users.username, cleanUser), eq(users.role, 'guru')));
    return res.json({ success: true, message: 'Guru berhasil dihapus' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/guru/bulk-import', requireAuth, async (req: Request, res: Response) => {
  try {
    const items = req.body;
    let added = 0;
    let skipped = 0;

    for (const item of items) {
      const cleanUser = String(item.username || '').replace(/'/g, '').trim();
      if (!cleanUser || !item.password) {
        skipped++;
        continue;
      }

      const existing = await db.select().from(users).where(eq(users.username, cleanUser)).limit(1);
      if (existing.length > 0) {
        skipped++;
        continue;
      }

      await db.insert(users).values({
        username: cleanUser,
        password: String(item.password).replace(/'/g, '').trim(),
        role: 'guru',
        nama: cleanUser,
        kelas: item.kelas || '',
      });
      added++;
    }

    return res.json({ success: true, added, skipped, message: `Import guru selesai. Berhasil: ${added}, Gagal/Duplikat: ${skipped}` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 4. KELAS CRUD
// ----------------------------------------------------------------------
apiRouter.get('/kelas', async (_req: Request, res: Response) => {
  try {
    const list = await db.select().from(kelas).orderBy(asc(kelas.nama));
    return res.json({ success: true, data: list.map(k => k.nama) });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.get('/kelas/master', async (_req: Request, res: Response) => {
  try {
    const list = await db.select().from(kelas).orderBy(asc(kelas.nama));
    return res.json({ success: true, data: list.map((k) => ({ rowIndex: k.id, nama: k.nama })) });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/kelas', requireAuth, async (req: Request, res: Response) => {
  try {
    const nama = String(req.body.namaKelas || req.body.nama || '').trim();
    if (!nama) return res.status(400).json({ success: false, message: 'Nama kelas tidak boleh kosong' });

    const existing = await db.select().from(kelas).where(eq(kelas.nama, nama)).limit(1);
    if (existing.length > 0) return res.status(400).json({ success: false, message: `Kelas "${nama}" sudah ada.` });

    await db.insert(kelas).values({ nama });
    return res.json({ success: true, message: `Kelas "${nama}" berhasil ditambahkan.` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.put('/kelas/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const namaBaru = String(req.body.namaBaru || req.body.nama || '').trim();
    if (!namaBaru) return res.status(400).json({ success: false, message: 'Nama kelas baru tidak boleh kosong' });

    const current = await db.select().from(kelas).where(eq(kelas.id, id)).limit(1);
    if (current.length === 0) return res.status(404).json({ success: false, message: 'Kelas tidak ditemukan' });
    const namaLama = current[0].nama;

    await db.update(kelas).set({ nama: namaBaru }).where(eq(kelas.id, id));
    // Propagate update to siswa table
    await db.update(siswa).set({ kelas: namaBaru }).where(eq(siswa.kelas, namaLama));

    return res.json({ success: true, message: `Kelas berhasil diubah dari "${namaLama}" ke "${namaBaru}".` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.delete('/kelas/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const current = await db.select().from(kelas).where(eq(kelas.id, id)).limit(1);
    if (current.length === 0) return res.status(404).json({ success: false, message: 'Kelas tidak ditemukan' });

    const namaKelas = current[0].nama;
    const siswaCount = await db.select({ count: sql<number>`count(*)` }).from(siswa).where(eq(siswa.kelas, namaKelas));
    const count = Number(siswaCount[0]?.count || 0);

    if (count > 0) {
      return res.status(400).json({
        success: false,
        message: `Kelas "${namaKelas}" masih digunakan oleh ${count} siswa. Pindahkan atau hapus siswa terlebih dahulu.`
      });
    }

    await db.delete(kelas).where(eq(kelas.id, id));
    return res.json({ success: true, message: `Kelas "${namaKelas}" berhasil dihapus.` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 5. HARI LIBUR & KONFIGURASI
// ----------------------------------------------------------------------
apiRouter.get('/hari-libur', async (_req: Request, res: Response) => {
  try {
    const list = await db.select().from(hariLibur).orderBy(desc(hariLibur.tanggal));
    return res.json({ success: true, data: list });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/hari-libur', requireAuth, async (req: Request, res: Response) => {
  try {
    const { tanggal, keterangan } = req.body;
    await db.insert(hariLibur).values({ tanggal, keterangan }).onConflictDoUpdate({
      target: hariLibur.tanggal,
      set: { keterangan }
    });
    return res.json({ success: true, message: 'Hari libur berhasil ditambahkan' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/hari-libur/range', requireAuth, async (req: Request, res: Response) => {
  try {
    const { tanggalMulai, tanggalAkhir, keterangan } = req.body;
    if (tanggalAkhir < tanggalMulai) {
      return res.status(400).json({ success: false, message: 'Tanggal akhir tidak boleh sebelum tanggal mulai.' });
    }

    const dMulai = new Date(tanggalMulai + 'T00:00:00');
    const dAkhir = new Date(tanggalAkhir + 'T00:00:00');
    let added = 0;

    for (let d = new Date(dMulai); d <= dAkhir; d.setDate(d.getDate() + 1)) {
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const dateStr = `${year}-${month}-${day}`;

      await db.insert(hariLibur).values({ tanggal: dateStr, keterangan }).onConflictDoNothing();
      added++;
    }

    return res.json({ success: true, message: `${added} hari libur berhasil ditambahkan.` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.put('/hari-libur', requireAuth, async (req: Request, res: Response) => {
  try {
    const { oldDate, newDate, newKeterangan } = req.body;
    if (oldDate !== newDate) {
      await db.delete(hariLibur).where(eq(hariLibur.tanggal, oldDate));
      await db.insert(hariLibur).values({ tanggal: newDate, keterangan: newKeterangan });
    } else {
      await db.update(hariLibur).set({ keterangan: newKeterangan }).where(eq(hariLibur.tanggal, oldDate));
    }
    return res.json({ success: true, message: 'Hari libur berhasil diperbarui' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.delete('/hari-libur/:tanggal', requireAuth, async (req: Request, res: Response) => {
  try {
    const tanggal = req.params.tanggal;
    await db.delete(hariLibur).where(eq(hariLibur.tanggal, tanggal));
    return res.json({ success: true, message: 'Hari libur dihapus' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/hari-libur/bulk-import', requireAuth, async (req: Request, res: Response) => {
  try {
    const items = req.body;
    let added = 0;
    for (const item of items) {
      if (item.tanggal && item.keterangan) {
        await db.insert(hariLibur).values({
          tanggal: String(item.tanggal).trim(),
          keterangan: String(item.keterangan).trim()
        }).onConflictDoNothing();
        added++;
      }
    }
    return res.json({ success: true, added, message: `Import hari libur selesai. Berhasil: ${added}` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.get('/config', async (_req: Request, res: Response) => {
  try {
    const data = await getAppConfigData();
    return res.json({ success: true, data });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/config', requireAuth, async (req: Request, res: Response) => {
  try {
    const newConfig = req.body;

    const upsertConfig = async (key: string, value: string) => {
      await db.insert(konfigurasi)
        .values({ key, value })
        .onConflictDoUpdate({ target: konfigurasi.key, set: { value } });
    };

    if (newConfig.jam_masuk_mulai) await upsertConfig('jam_masuk_mulai', newConfig.jam_masuk_mulai);
    if (newConfig.jam_masuk_akhir) await upsertConfig('jam_masuk_akhir', newConfig.jam_masuk_akhir);
    if (newConfig.jam_pulang_mulai) await upsertConfig('jam_pulang_mulai', newConfig.jam_pulang_mulai);
    if (newConfig.jam_pulang_akhir) await upsertConfig('jam_pulang_akhir', newConfig.jam_pulang_akhir);
    if (newConfig.mode_absen) await upsertConfig('mode_absen', newConfig.mode_absen);
    if (newConfig.jadwal_harian) {
      const val = typeof newConfig.jadwal_harian === 'string' ? newConfig.jadwal_harian : JSON.stringify(newConfig.jadwal_harian);
      await upsertConfig('jadwal_harian', val);
    }

    return res.json({ success: true, message: 'Konfigurasi waktu berhasil disimpan' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 6. REALTIME PRESENSI & SCAN
// ----------------------------------------------------------------------

// Helper: Check holiday
async function checkHolidayStatus(dateStr: string, config: any) {
  const d = new Date(dateStr + 'T00:00:00');
  let jsDay = d.getDay(); // 0=Sunday, 1=Monday... 6=Saturday
  const dayKey = jsDay === 0 ? '7' : String(jsDay);
  const dayNames: Record<string, string> = { '1': 'Senin', '2': 'Selasa', '3': 'Rabu', '4': 'Kamis', '5': 'Jumat', '6': 'Sabtu', '7': 'Minggu' };

  if (config.jadwal_harian && config.jadwal_harian[dayKey]?.libur) {
    return { isHoliday: true, message: `Absensi DITUTUP. Hari ini libur rutin: Hari ${dayNames[dayKey] || ''}` };
  } else if (dayKey === '7') {
    return { isHoliday: true, message: 'Absensi DITUTUP. Hari ini libur rutin: Hari Minggu' };
  }

  const libur = await db.select().from(hariLibur).where(eq(hariLibur.tanggal, dateStr)).limit(1);
  if (libur.length > 0) {
    return { isHoliday: true, message: `Absensi DITUTUP. Hari ini libur: ${libur[0].keterangan}` };
  }

  return { isHoliday: false, message: '' };
}

apiRouter.get('/absensi/today/:nisn', async (req: Request, res: Response) => {
  try {
    const cleanNisn = String(req.params.nisn).trim();
    const today = getTodayStr();
    const config = await getAppConfigData();

    const holidayInfo = await checkHolidayStatus(today, config);

    const rec = await db.select().from(absensi)
      .where(and(eq(absensi.tanggal, today), eq(absensi.nisn, cleanNisn)))
      .limit(1);

    return res.json({
      success: true,
      data: rec.length > 0 ? {
        tanggal: rec[0].tanggal,
        jamDatang: rec[0].jamDatang || '',
        jamPulang: rec[0].jamPulang || '',
        status: rec[0].status || 'Hadir',
      } : null,
      isLibur: holidayInfo.isHoliday,
      keteranganLibur: holidayInfo.message,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.get('/absensi/monitoring', async (req: Request, res: Response) => {
  try {
    const today = getTodayStr();
    const filterKelas = req.query.filterKelas as string;

    const siswaQuery = filterKelas && filterKelas !== 'SEMUA'
      ? db.select().from(siswa).where(inArray(siswa.kelas, filterKelas.split(',').map(k => k.trim())))
      : db.select().from(siswa);

    const allSiswa = await siswaQuery.orderBy(asc(siswa.kelas), asc(siswa.nama));
    const allAbsenToday = await db.select().from(absensi).where(eq(absensi.tanggal, today));

    const absenMap: Record<string, typeof absensi.$inferSelect> = {};
    allAbsenToday.forEach(a => { absenMap[a.nisn] = a; });

    const result = allSiswa.map(s => {
      const a = absenMap[s.nisn];
      let jamDatang = '-';
      let jamPulang = '-';
      let status = 'Belum Absen';
      let keterangan = '-';

      if (a) {
        jamDatang = a.jamDatang || '-';
        jamPulang = a.jamPulang || '-';
        status = a.status || 'Hadir';
        keterangan = a.keterangan || (status === 'Hadir' ? 'Tepat Waktu' : '-');
      }

      return {
        nama: s.nama,
        nisn: s.nisn,
        kelas: s.kelas,
        jamDatang,
        jamPulang,
        status,
        keterangan,
      };
    });

    return res.json({ success: true, data: result });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/absensi/status', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { nisn, nama, kelas: siswaKelas, status: newStatus } = req.body;
    const cleanNisn = String(nisn).trim();
    const today = getTodayStr();
    const nowTime = getNowTimeSecStr();

    const existing = await db.select().from(absensi)
      .where(and(eq(absensi.tanggal, today), eq(absensi.nisn, cleanNisn)))
      .limit(1);

    if (existing.length > 0) {
      await db.update(absensi)
        .set({
          status: newStatus,
          jamDatang: (newStatus === 'Hadir' && !existing[0].jamDatang) ? nowTime : existing[0].jamDatang,
        })
        .where(eq(absensi.id, existing[0].id));
    } else {
      await db.insert(absensi).values({
        tanggal: today,
        nisn: cleanNisn,
        nama,
        kelas: siswaKelas,
        jamDatang: newStatus === 'Hadir' ? nowTime : '',
        jamPulang: '',
        keterangan: newStatus === 'Hadir' ? 'Tepat Waktu' : 'Status Manual',
        status: newStatus,
      });
    }

    return res.json({ success: true, message: 'Status berhasil diubah', jamDatang: nowTime });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// Single QR Scan
apiRouter.post('/absensi/scan', async (req: Request, res: Response) => {
  try {
    const { nisn, scannerRole, scannerKelas, scanMode = 'auto' } = req.body;
    const cleanNisn = String(nisn || '').replace(/[^a-zA-Z0-9]/g, '').trim();

    if (!cleanNisn) {
      return res.status(400).json({ success: false, message: 'QR Code tidak valid atau kosong.' });
    }

    const today = getTodayStr();
    const nowTime = getNowTimeStr();
    const nowSecTime = getNowTimeSecStr();

    const config = await getAppConfigData();

    // 1. Check Holiday & Day schedule
    const holidayInfo = await checkHolidayStatus(today, config);
    if (holidayInfo.isHoliday) {
      return res.json({ success: false, message: holidayInfo.message });
    }

    // 2. Lookup student
    const s = await db.select().from(siswa).where(eq(siswa.nisn, cleanNisn)).limit(1);
    if (s.length === 0) {
      return res.json({ success: false, message: 'NISN tidak terdaftar di database.' });
    }
    const targetSiswa = s[0];

    // 3. Scanner teacher class constraint
    if (scannerRole === 'guru' && scannerKelas && scannerKelas !== 'SEMUA') {
      const allowedKelas = String(scannerKelas).split(',').map(k => k.trim().toUpperCase());
      if (!allowedKelas.includes(targetSiswa.kelas.toUpperCase())) {
        return res.json({
          success: false,
          message: `Ditolak! Siswa ini kelas ${targetSiswa.kelas}. Anda hanya bisa scan kelas ${scannerKelas}.`
        });
      }
    }

    // 4. Check existing today record
    const existing = await db.select().from(absensi)
      .where(and(eq(absensi.tanggal, today), eq(absensi.nisn, cleanNisn)))
      .limit(1);

    const modeAbsen = scanMode === 'pulang' ? 'masuk_pulang' : (config.mode_absen || 'masuk_pulang');

    if (existing.length > 0) {
      const rec = existing[0];

      if (modeAbsen === 'masuk_saja') {
        return res.json({ success: false, message: `${targetSiswa.nama} sudah absen masuk hari ini.` });
      }

      if (scanMode === 'masuk') {
        return res.json({
          success: false,
          code: 'ALREADY_MASUK',
          message: `${targetSiswa.nama} sudah absen datang hari ini.`,
          nama: targetSiswa.nama,
          kelas: targetSiswa.kelas,
          status: rec.status,
          jamDatang: rec.jamDatang || '',
          jamPulang: rec.jamPulang || '',
        });
      }

      if (rec.jamPulang) {
        return res.json({
          success: false,
          code: 'ALREADY_PULANG',
          message: `${targetSiswa.nama} sudah absen pulang hari ini.`,
          nama: targetSiswa.nama,
          jamPulang: rec.jamPulang,
        });
      }

      // Record Pulang
      let ketBaru = rec.keterangan || '';
      let pesanPulang = 'Absen Pulang Berhasil';
      if (nowTime < config.jam_pulang_mulai) {
        ketBaru = (ketBaru ? ketBaru + ' & ' : '') + 'Pulang Cepat';
        pesanPulang = 'Absen Pulang (Pulang Cepat)';
      }

      await db.update(absensi)
        .set({ jamPulang: nowSecTime, keterangan: ketBaru })
        .where(eq(absensi.id, rec.id));

      return res.json({
        success: true,
        message: pesanPulang,
        type: 'pulang',
        jamPulang: nowSecTime,
        nama: targetSiswa.nama,
        kelas: targetSiswa.kelas,
        status: 'Hadir',
      });
    }

    // If scanning in 'pulang' mode but not checked in yet
    if (scanMode === 'pulang') {
      return res.json({
        success: false,
        code: 'BELUM_MASUK',
        message: `${targetSiswa.nama} belum melakukan absen datang hari ini.`,
        nama: targetSiswa.nama,
        kelas: targetSiswa.kelas,
      });
    }

    // New check-in (Masuk)
    if (nowTime < config.jam_masuk_mulai) {
      return res.json({ success: false, message: `Absensi belum dibuka. Buka mulai jam ${config.jam_masuk_mulai}.` });
    }

    let keteranganWaktu = 'Tepat Waktu';
    if (nowTime > config.jam_masuk_akhir) {
      const lateMinutes = calculateTimeDiffMinutes(config.jam_masuk_akhir, nowTime);
      keteranganWaktu = `Terlambat ${lateMinutes} menit`;
    }

    await db.insert(absensi).values({
      tanggal: today,
      nisn: cleanNisn,
      nama: targetSiswa.nama,
      kelas: targetSiswa.kelas,
      jamDatang: nowSecTime,
      jamPulang: '',
      keterangan: keteranganWaktu,
      status: 'Hadir',
    });

    return res.json({
      success: true,
      message: keteranganWaktu.includes('Terlambat') ? `Absen Masuk (${keteranganWaktu})` : 'Absen Masuk Berhasil ✓',
      type: 'datang',
      jamDatang: nowSecTime,
      nama: targetSiswa.nama,
      kelas: targetSiswa.kelas,
      status: 'Hadir',
    });
  } catch (error: any) {
    console.error('Scan error:', error);
    return res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
});

// Batch Scan
apiRouter.post('/absensi/batch-scan', async (req: Request, res: Response) => {
  try {
    const { nisnList, scannerRole, scannerKelas } = req.body;
    if (!Array.isArray(nisnList) || nisnList.length === 0) {
      return res.status(400).json({ success: false, message: 'Antrian scan kosong' });
    }

    const today = getTodayStr();
    const nowTime = getNowTimeStr();
    const nowSecTime = getNowTimeSecStr();
    const config = await getAppConfigData();

    const holidayInfo = await checkHolidayStatus(today, config);
    if (holidayInfo.isHoliday) {
      return res.json({ success: false, message: holidayInfo.message });
    }

    const allSiswa = await db.select().from(siswa);
    const siswaMap: Record<string, typeof siswa.$inferSelect> = {};
    allSiswa.forEach(s => { siswaMap[s.nisn] = s; });

    const existingAbsensi = await db.select().from(absensi).where(eq(absensi.tanggal, today));
    const absensiMap: Record<string, typeof absensi.$inferSelect> = {};
    existingAbsensi.forEach(a => { absensiMap[a.nisn] = a; });

    const results = [];

    for (const rawNisn of nisnList) {
      const cleanNisn = String(rawNisn).trim();
      const s = siswaMap[cleanNisn];
      if (!s) {
        results.push({ nisn: cleanNisn, success: false, message: 'NISN tidak terdaftar' });
        continue;
      }

      if (scannerRole === 'guru' && scannerKelas && scannerKelas !== 'SEMUA') {
        const allowedKelas = String(scannerKelas).split(',').map(k => k.trim().toUpperCase());
        if (!allowedKelas.includes(s.kelas.toUpperCase())) {
          results.push({ nisn: cleanNisn, nama: s.nama, kelas: s.kelas, success: false, message: `Ditolak! Siswa kelas ${s.kelas}, bukan kelas Anda.` });
          continue;
        }
      }

      const existingRecord = absensiMap[cleanNisn];
      if (existingRecord) {
        if (existingRecord.jamPulang) {
          results.push({ nisn: cleanNisn, nama: s.nama, kelas: s.kelas, success: false, message: 'Sudah absen pulang hari ini.' });
        } else {
          let ketBaru = existingRecord.keterangan || '';
          if (nowTime < config.jam_pulang_mulai) {
            ketBaru = (ketBaru ? ketBaru + ' & ' : '') + 'Pulang Cepat';
          }
          await db.update(absensi).set({ jamPulang: nowSecTime, keterangan: ketBaru }).where(eq(absensi.id, existingRecord.id));
          results.push({ nisn: cleanNisn, nama: s.nama, kelas: s.kelas, success: true, type: 'pulang', jamPulang: nowSecTime, message: 'Absen Pulang Berhasil' });
        }
      } else {
        let keterangan = 'Tepat Waktu';
        if (nowTime > config.jam_masuk_akhir) {
          const lateMinutes = calculateTimeDiffMinutes(config.jam_masuk_akhir, nowTime);
          keterangan = `Terlambat ${lateMinutes} menit`;
        }
        await db.insert(absensi).values({
          tanggal: today,
          nisn: cleanNisn,
          nama: s.nama,
          kelas: s.kelas,
          jamDatang: nowSecTime,
          jamPulang: '',
          keterangan,
          status: 'Hadir',
        });
        results.push({ nisn: cleanNisn, nama: s.nama, kelas: s.kelas, success: true, type: 'datang', jamDatang: nowSecTime, message: 'Absen Masuk Berhasil' });
      }
    }

    return res.json({ success: true, results });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// Daftar Hadir Guru: By Class & Date
apiRouter.get('/absensi/daftar-hadir', async (req: Request, res: Response) => {
  try {
    const { kelas: filterKelas, tanggal } = req.query as { kelas: string; tanggal: string };
    if (!tanggal) return res.json({ success: true, data: {} });

    let query = db.select().from(absensi).where(eq(absensi.tanggal, tanggal));
    const records = await query;

    const result: Record<string, { status: string; jamDatang: string; hasJamDatang: boolean }> = {};
    const allowed = filterKelas && filterKelas !== 'SEMUA' ? filterKelas.split(',').map(k => k.trim().toUpperCase()) : null;

    records.forEach(r => {
      if (!allowed || allowed.includes(r.kelas.toUpperCase())) {
        result[r.nisn] = {
          status: r.status.toLowerCase(),
          jamDatang: r.jamDatang ? r.jamDatang.substring(0, 5) : '',
          hasJamDatang: !!r.jamDatang,
        };
      }
    });

    return res.json({ success: true, data: result });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// Daftar Hadir Guru: Detail By Class & Date
apiRouter.get('/absensi/daftar-hadir-detail', async (req: Request, res: Response) => {
  try {
    const { kelas: filterKelas, tanggal } = req.query as { kelas: string; tanggal: string };
    if (!tanggal) return res.json({ success: true, data: {} });

    const records = await db.select().from(absensi).where(eq(absensi.tanggal, tanggal));
    const result: Record<string, { status: string; jamDatang: string; jamPulang: string; rowIndex: number }> = {};
    const allowed = filterKelas && filterKelas !== 'SEMUA' ? filterKelas.split(',').map(k => k.trim().toUpperCase()) : null;

    records.forEach(r => {
      if (!allowed || allowed.includes(r.kelas.toUpperCase())) {
        result[r.nisn] = {
          status: r.status.toLowerCase(),
          jamDatang: r.jamDatang ? r.jamDatang.substring(0, 5) : '',
          jamPulang: r.jamPulang ? r.jamPulang.substring(0, 5) : '',
          rowIndex: r.id,
        };
      }
    });

    return res.json({ success: true, data: result });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/absensi/pulang-satu', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { nisn, tanggal } = req.body;
    const cleanNisn = String(nisn).trim();
    const nowSecTime = getNowTimeSecStr();
    const nowTime = getNowTimeStr();
    const config = await getAppConfigData();

    const rec = await db.select().from(absensi)
      .where(and(eq(absensi.tanggal, tanggal), eq(absensi.nisn, cleanNisn)))
      .limit(1);

    if (rec.length === 0) {
      return res.status(404).json({ success: false, message: 'Data absen masuk tidak ditemukan. Siswa belum melakukan absen datang.' });
    }

    if (rec[0].status !== 'Hadir') {
      return res.status(400).json({ success: false, message: `Siswa berstatus ${rec[0].status}, tidak perlu absen pulang.` });
    }

    if (rec[0].jamPulang) {
      return res.status(400).json({ success: false, message: `${rec[0].nama} sudah tercatat pulang (${rec[0].jamPulang}).` });
    }

    let ketBaru = rec[0].keterangan || 'Tepat Waktu';
    if (nowTime < config.jam_pulang_mulai && !ketBaru.includes('Pulang Cepat')) {
      ketBaru = `${ketBaru} & Pulang Cepat`;
    }

    await db.update(absensi).set({ jamPulang: nowSecTime, keterangan: ketBaru }).where(eq(absensi.id, rec[0].id));

    return res.json({
      success: true,
      nama: rec[0].nama,
      jamPulang: nowSecTime,
      message: `${rec[0].nama} berhasil dicatat pulang (${nowSecTime})`,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/absensi/pulang-semua-hadir', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { kelas: filterKelas, tanggal, namaPengirim } = req.body;
    const nowSecTime = getNowTimeSecStr();
    const nowTime = getNowTimeStr();
    const config = await getAppConfigData();

    let conditions = [
      eq(absensi.tanggal, tanggal),
      eq(absensi.status, 'Hadir'),
      or(sql`jam_pulang IS NULL`, eq(absensi.jamPulang, ''))
    ];

    if (filterKelas && filterKelas !== 'SEMUA') {
      const allowedKelas = String(filterKelas).split(',').map(k => k.trim());
      conditions.push(inArray(absensi.kelas, allowedKelas));
    }

    const eligible = await db.select().from(absensi).where(and(...conditions));
    if (eligible.length === 0) {
      return res.json({ success: true, count: 0, message: 'Tidak ada siswa berstatus Hadir yang belum absen pulang.' });
    }

    let count = 0;
    for (const rec of eligible) {
      let ketBaru = rec.keterangan || 'Tepat Waktu';
      if (nowTime < config.jam_pulang_mulai && !ketBaru.includes('Pulang Cepat')) {
        ketBaru = `${ketBaru} & Pulang Cepat (Input: ${namaPengirim || 'Guru'})`;
      }
      await db.update(absensi).set({
        jamPulang: nowSecTime,
        keterangan: ketBaru,
      }).where(eq(absensi.id, rec.id));
      count++;
    }

    return res.json({
      success: true,
      count,
      message: `${count} siswa Hadir berhasil dicatat pulang (${nowSecTime}). Keterangan Sakit/Izin/Alpa tetap terjaga.`,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/absensi/pulang-massal', requireAuth, async (req: Request, res: Response) => {
  try {
    const { pulangList, tanggal, namaPengirim } = req.body;
    if (!Array.isArray(pulangList) || pulangList.length === 0) {
      return res.status(400).json({ success: false, message: 'Daftar pulang kosong' });
    }

    const nowSecTime = getNowTimeSecStr();
    let count = 0;

    for (const item of pulangList) {
      const id = item.rowIndex;
      if (id) {
        await db.update(absensi).set({
          jamPulang: nowSecTime,
          keterangan: sql`CONCAT(keterangan, ' & Pulang (Input: ', ${namaPengirim || 'Guru'}, ')')`,
        }).where(eq(absensi.id, id));
        count++;
      }
    }

    return res.json({ success: true, message: `${count} siswa berhasil dicatat pulang.` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/absensi/submit-daftar-hadir', requireAuth, async (req: Request, res: Response) => {
  try {
    const { dataList, tanggal, namaPengirim } = req.body;
    if (!Array.isArray(dataList) || dataList.length === 0) {
      return res.status(400).json({ success: false, message: 'Data absensi kosong' });
    }

    const nisnList = dataList.map(d => String(d.nisn).trim());
    // Delete existing on this date
    await db.delete(absensi).where(and(eq(absensi.tanggal, tanggal), inArray(absensi.nisn, nisnList)));

    const nowSecTime = getNowTimeSecStr();

    for (const d of dataList) {
      const isHadir = String(d.status).toLowerCase() === 'hadir';
      await db.insert(absensi).values({
        tanggal,
        nisn: String(d.nisn).trim(),
        nama: d.nama,
        kelas: d.kelas,
        jamDatang: isHadir ? nowSecTime : '',
        jamPulang: '',
        keterangan: isHadir ? `Tepat Waktu (Input: ${namaPengirim || 'Guru'})` : `Input: ${namaPengirim || 'Guru'}`,
        status: isHadir ? 'Hadir' : (d.status === 'sakit' ? 'Sakit' : (d.status === 'izin' ? 'Izin' : 'Alpa')),
      });
    }

    return res.json({ success: true, message: `${dataList.length} data absensi berhasil disimpan.` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 7. LAPORAN & REKAP
// ----------------------------------------------------------------------
apiRouter.get('/absensi/rekap', async (req: Request, res: Response) => {
  try {
    const { tanggalMulai, tanggalAkhir, kelas: filterKelas } = req.query as {
      tanggalMulai?: string;
      tanggalAkhir?: string;
      kelas?: string;
    };

    let siswaQuery = db.select().from(siswa);
    if (filterKelas && filterKelas !== 'SEMUA') {
      const kList = filterKelas.split(',').map(k => k.trim());
      siswaQuery = db.select().from(siswa).where(inArray(siswa.kelas, kList)) as any;
    }
    const studentList = await siswaQuery.orderBy(asc(siswa.kelas), asc(siswa.nama));

    const todayStr = getTodayStr();
    const fStart = tanggalMulai || todayStr;
    const fEnd = tanggalAkhir || todayStr;

    const absensiRecords = await db.select().from(absensi)
      .where(and(sql`tanggal >= ${fStart}`, sql`tanggal <= ${fEnd}`));

    const absenMap: Record<string, typeof absensi.$inferSelect> = {};
    absensiRecords.forEach(a => {
      absenMap[`${a.tanggal}_${a.nisn}`] = a;
    });

    const result = [];
    const dStart = new Date(fStart + 'T00:00:00');
    const dEnd = new Date(fEnd + 'T00:00:00');

    for (let d = new Date(dStart); d <= dEnd; d.setDate(d.getDate() + 1)) {
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const curDateStr = `${year}-${month}-${day}`;

      for (const s of studentList) {
        const item = absenMap[`${curDateStr}_${s.nisn}`];
        if (item) {
          result.push({
            tanggal: curDateStr,
            nisn: s.nisn,
            nama: s.nama,
            kelas: s.kelas,
            jamDatang: item.jamDatang || '-',
            jamPulang: item.jamPulang || '-',
            keterangan: item.keterangan || '-',
            status: item.status || 'Hadir',
          });
        } else {
          result.push({
            tanggal: curDateStr,
            nisn: s.nisn,
            nama: s.nama,
            kelas: s.kelas,
            jamDatang: '-',
            jamPulang: '-',
            keterangan: '-',
            status: curDateStr > todayStr ? '' : 'Belum Absen',
          });
        }
      }
    }

    return res.json({ success: true, data: result });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.get('/absensi/rekap-bulanan', async (req: Request, res: Response) => {
  try {
    const bulan = parseInt(req.query.bulan as string); // 0 = Jan, 11 = Dec
    const tahun = parseInt(req.query.tahun as string);
    const kelasFilter = req.query.kelas as string;

    const startDate = new Date(tahun, bulan, 1);
    const endDate = new Date(tahun, bulan + 1, 0);
    const daysInMonth = endDate.getDate();

    const startStr = `${tahun}-${String(bulan + 1).padStart(2, '0')}-01`;
    const endStr = `${tahun}-${String(bulan + 1).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}`;
    const todayStr = getTodayStr();

    const config = await getAppConfigData();
    const holidays = await db.select().from(hariLibur).where(and(sql`tanggal >= ${startStr}`, sql`tanggal <= ${endStr}`));
    const holidayMap: Record<string, string> = {};
    holidays.forEach(h => { holidayMap[h.tanggal] = h.keterangan; });

    let siswaQuery = db.select().from(siswa);
    if (kelasFilter && kelasFilter !== 'SEMUA') {
      siswaQuery = db.select().from(siswa).where(inArray(siswa.kelas, kelasFilter.split(',').map(k => k.trim()))) as any;
    }
    const studentList = await siswaQuery.orderBy(asc(siswa.nama));

    const absensiRows = await db.select().from(absensi)
      .where(and(sql`tanggal >= ${startStr}`, sql`tanggal <= ${endStr}`));
    const absenMap: Record<string, string> = {};
    absensiRows.forEach(a => { absenMap[`${a.tanggal}_${a.nisn}`] = a.status; });

    const students = studentList.map(s => {
      const stats = { h: 0, s: 0, i: 0, a: 0, effectiveDays: 0 };
      const dailyCodes = [];

      for (let day = 1; day <= daysInMonth; day++) {
        const curDate = new Date(tahun, bulan, day);
        const curStr = `${tahun}-${String(bulan + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const isHoliday = !!holidayMap[curStr];
        const jsDay = curDate.getDay();
        const dayKey = jsDay === 0 ? '7' : String(jsDay);
        const isRoutineOff = (config.jadwal_harian as Record<string, any>)?.[dayKey]?.libur || jsDay === 0;

        let code = '-';
        const isDayOff = isHoliday || isRoutineOff;

        if (isDayOff) {
          code = 'L';
        } else if (curStr > todayStr) {
          code = '';
        } else {
          stats.effectiveDays++;
          const st = absenMap[`${curStr}_${s.nisn}`];
          if (st === 'Hadir') { code = 'H'; stats.h++; }
          else if (st === 'Sakit') { code = 'S'; stats.s++; }
          else if (st === 'Izin') { code = 'I'; stats.i++; }
          else { code = 'A'; stats.a++; }
        }

        dailyCodes.push({ date: day, code, isHoliday: isDayOff });
      }

      const percent = stats.effectiveDays > 0 ? Math.round((stats.h / stats.effectiveDays) * 100) : 0;
      return {
        nama: s.nama,
        nisn: s.nisn,
        kelas: s.kelas,
        dailyCodes,
        stats: { ...stats, percent },
      };
    });

    return res.json({ success: true, data: { daysInMonth, students } });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// Excel Export generator directly with SheetJS xlsx
apiRouter.post('/absensi/export-excel', async (req: Request, res: Response) => {
  try {
    const { type, filters } = req.body;
    const wb = XLSX.utils.book_new();

    if (type === 'laporan_bulanan') {
      const { bulan, tahun, kelas } = filters;
      // Get monthly report data
      const startDate = new Date(tahun, bulan, 1);
      const endDate = new Date(tahun, bulan + 1, 0);
      const daysInMonth = endDate.getDate();
      const startStr = `${tahun}-${String(bulan + 1).padStart(2, '0')}-01`;
      const endStr = `${tahun}-${String(bulan + 1).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}`;

      const config = await getAppConfigData();
      const holidays = await db.select().from(hariLibur).where(and(sql`tanggal >= ${startStr}`, sql`tanggal <= ${endStr}`));
      const holidayMap: Record<string, string> = {};
      holidays.forEach(h => { holidayMap[h.tanggal] = h.keterangan; });

      let siswaQuery = db.select().from(siswa);
      if (kelas && kelas !== 'SEMUA') {
        siswaQuery = db.select().from(siswa).where(inArray(siswa.kelas, kelas.split(',').map((k: string) => k.trim()))) as any;
      }
      const studentList = await siswaQuery.orderBy(asc(siswa.nama));

      const absensiRows = await db.select().from(absensi)
        .where(and(sql`tanggal >= ${startStr}`, sql`tanggal <= ${endStr}`));
      const absenMap: Record<string, string> = {};
      absensiRows.forEach(a => { absenMap[`${a.tanggal}_${a.nisn}`] = a.status; });

      const headers = ['No', 'Nama Siswa', 'NISN', 'Kelas'];
      for (let d = 1; d <= daysInMonth; d++) headers.push(String(d));
      headers.push('H', 'S', 'I', 'A', '%');

      const rows: any[][] = [headers];

      studentList.forEach((s, idx) => {
        const row: any[] = [idx + 1, s.nama, s.nisn, s.kelas];
        let h = 0, sc = 0, i = 0, a = 0, eff = 0;

        for (let day = 1; day <= daysInMonth; day++) {
          const curStr = `${tahun}-${String(bulan + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const isHoliday = !!holidayMap[curStr];
          const jsDay = new Date(tahun, bulan, day).getDay();
          const dayKey = jsDay === 0 ? '7' : String(jsDay);
          const isRoutineOff = (config.jadwal_harian as Record<string, any>)?.[dayKey]?.libur || jsDay === 0;

          if (isHoliday || isRoutineOff) {
            row.push('L');
          } else {
            eff++;
            const st = absenMap[`${curStr}_${s.nisn}`];
            if (st === 'Hadir') { row.push('H'); h++; }
            else if (st === 'Sakit') { row.push('S'); sc++; }
            else if (st === 'Izin') { row.push('I'); i++; }
            else { row.push('A'); a++; }
          }
        }
        const pct = eff > 0 ? Math.round((h / eff) * 100) : 0;
        row.push(h, sc, i, a, `${pct}%`);
        rows.push(row);
      });

      const ws = XLSX.utils.aoa_to_sheet(rows);
      XLSX.utils.book_append_sheet(wb, ws, 'Rekap Bulanan');
    } else {
      // Detail Log & Monitoring
      const fStart = filters.tanggalMulai || getTodayStr();
      const fEnd = filters.tanggalAkhir || getTodayStr();
      const filterKelas = filters.kelas;

      let siswaQuery = db.select().from(siswa);
      if (filterKelas && filterKelas !== 'SEMUA') {
        siswaQuery = db.select().from(siswa).where(inArray(siswa.kelas, filterKelas.split(',').map((k: string) => k.trim()))) as any;
      }
      const studentList = await siswaQuery.orderBy(asc(siswa.kelas), asc(siswa.nama));

      const absensiRows = await db.select().from(absensi)
        .where(and(sql`tanggal >= ${fStart}`, sql`tanggal <= ${fEnd}`));
      const absenMap: Record<string, typeof absensi.$inferSelect> = {};
      absensiRows.forEach(a => { absenMap[`${a.tanggal}_${a.nisn}`] = a; });

      const logRows: any[][] = [['No', 'Tanggal', 'NISN', 'Nama Siswa', 'Kelas', 'Jam Datang', 'Jam Pulang', 'Keterangan', 'Status']];
      let counter = 1;

      const dStart = new Date(fStart + 'T00:00:00');
      const dEnd = new Date(fEnd + 'T00:00:00');

      for (let d = new Date(dStart); d <= dEnd; d.setDate(d.getDate() + 1)) {
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const curDateStr = `${year}-${month}-${day}`;

        for (const s of studentList) {
          const item = absenMap[`${curDateStr}_${s.nisn}`];
          logRows.push([
            counter++,
            curDateStr,
            s.nisn,
            s.nama,
            s.kelas,
            item?.jamDatang || '-',
            item?.jamPulang || '-',
            item?.keterangan || (item?.status === 'Hadir' ? 'Tepat Waktu' : '-'),
            item?.status || 'Belum Absen',
          ]);
        }
      }

      const ws = XLSX.utils.aoa_to_sheet(logRows);
      XLSX.utils.book_append_sheet(wb, ws, 'Detail Log Presensi');
    }

    const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=Presensi_${Date.now()}.xlsx`);
    return res.send(buffer);
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 8. ABSENSI SHOLAT
// ----------------------------------------------------------------------
apiRouter.get('/sholat', async (req: Request, res: Response) => {
  try {
    const { kelas: filterKelas, tanggal, waktuSholat } = req.query as {
      kelas?: string;
      tanggal?: string;
      waktuSholat?: string;
    };

    let query = db.select().from(absensiSholat);
    const conditions = [];
    if (tanggal) conditions.push(eq(absensiSholat.tanggal, tanggal));
    if (waktuSholat) conditions.push(eq(absensiSholat.waktuSholat, waktuSholat));
    if (filterKelas && filterKelas !== 'SEMUA') {
      conditions.push(inArray(absensiSholat.kelas, filterKelas.split(',').map(k => k.trim())));
    }

    if (conditions.length > 0) {
      query = db.select().from(absensiSholat).where(and(...conditions)) as any;
    }

    const rows = await query;
    const map: Record<string, { status: string; keterangan: string }> = {};
    rows.forEach(r => {
      map[r.nisn] = { status: r.status, keterangan: r.keterangan || '' };
    });

    return res.json({ success: true, data: map });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/sholat', requireAuth, async (req: Request, res: Response) => {
  try {
    const { dataList, tanggal, waktuSholat, inputOleh } = req.body;
    if (!Array.isArray(dataList) || dataList.length === 0) {
      return res.status(400).json({ success: false, message: 'Data sholat kosong' });
    }

    const nisnList = dataList.map(d => String(d.nisn).trim());
    await db.delete(absensiSholat).where(
      and(
        eq(absensiSholat.tanggal, tanggal),
        eq(absensiSholat.waktuSholat, waktuSholat),
        inArray(absensiSholat.nisn, nisnList)
      )
    );

    for (const d of dataList) {
      await db.insert(absensiSholat).values({
        tanggal,
        nisn: String(d.nisn).trim(),
        nama: d.nama,
        kelas: d.kelas,
        waktuSholat,
        status: d.status,
        keterangan: d.keterangan || '',
        inputOleh: inputOleh || 'Guru',
      });
    }

    return res.json({ success: true, message: `${dataList.length} data absensi sholat berhasil disimpan.` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.get('/sholat/rekap', async (req: Request, res: Response) => {
  try {
    const { kelas: filterKelas, bulan, waktuSholat } = req.query as {
      kelas?: string;
      bulan?: string; // YYYY-MM
      waktuSholat?: string;
    };

    const ym = bulan || getTodayStr().substring(0, 7);

    const conditions = [sql`tanggal LIKE ${ym + '%'}`];
    if (waktuSholat) conditions.push(eq(absensiSholat.waktuSholat, waktuSholat));
    if (filterKelas && filterKelas !== 'SEMUA') {
      conditions.push(inArray(absensiSholat.kelas, filterKelas.split(',').map(k => k.trim())));
    }

    const rows = await db.select().from(absensiSholat)
      .where(and(...conditions))
      .orderBy(asc(absensiSholat.tanggal), asc(absensiSholat.nama));

    return res.json({ success: true, data: rows });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 9. WHATSAPP LOG NOTIFIKASI
// ----------------------------------------------------------------------
apiRouter.get('/whatsapp/status', async (req: Request, res: Response) => {
  try {
    const { kelas: filterKelas, tanggal } = req.query as { kelas?: string; tanggal?: string };
    const conditions = [];
    if (tanggal) conditions.push(eq(logNotifikasiWa.tanggalAbsensi, tanggal));
    if (filterKelas && filterKelas !== 'SEMUA') {
      conditions.push(inArray(logNotifikasiWa.kelas, filterKelas.split(',').map(k => k.trim())));
    }

    const logs = await db.select().from(logNotifikasiWa).where(and(...conditions));
    const result: Record<string, { sudahDikirim: boolean; waktu: string }> = {};
    logs.forEach(l => {
      result[l.nisn] = { sudahDikirim: true, waktu: l.waktuDikirim };
    });

    return res.json({ success: true, data: result });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/whatsapp/kirim', requireAuth, async (req: Request, res: Response) => {
  try {
    const { nisn, tanggal } = req.body;
    const cleanNisn = String(nisn).trim();

    const s = await db.select().from(siswa).where(eq(siswa.nisn, cleanNisn)).limit(1);
    if (s.length === 0) return res.status(404).json({ success: false, message: 'Siswa tidak ditemukan' });

    const nowStr = `${getTodayStr()} ${getNowTimeSecStr()}`;

    await db.insert(logNotifikasiWa).values({
      waktuDikirim: nowStr,
      tanggalAbsensi: tanggal,
      nisn: cleanNisn,
      nama: s[0].nama,
      kelas: s[0].kelas,
      status: 'Sudah Dikirim',
    });

    return res.json({ success: true, message: 'Notifikasi berhasil dicatat.', data: { nisn: cleanNisn, nama: s[0].nama, kelas: s[0].kelas, waktu: nowStr } });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ----------------------------------------------------------------------
// 10. PROMOSI / KENAIKAN KELAS & ARSIP
// ----------------------------------------------------------------------
apiRouter.post('/promosi/proses', requireAuth, async (req: Request, res: Response) => {
  try {
    const { kelasAsal, kelasTujuan, promoData } = req.body;
    if (!Array.isArray(promoData)) return res.status(400).json({ success: false, message: 'Data promosi kosong' });

    for (const p of promoData) {
      if (p.status === 'NAIK') {
        if (kelasTujuan === 'LULUS') {
          // Can mark or remove
          await db.delete(siswa).where(eq(siswa.nisn, p.nisn));
        } else {
          await db.update(siswa).set({ kelas: kelasTujuan }).where(eq(siswa.nisn, p.nisn));
        }
      }
    }

    return res.json({ success: true, message: 'Kenaikan kelas berhasil diproses.' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

apiRouter.post('/arsip/reset', requireAuth, async (req: Request, res: Response) => {
  try {
    const { namaArsip } = req.body;
    // Clear attendance records for fresh academic year
    await db.delete(absensi);
    await db.delete(absensiSholat);
    await db.delete(logNotifikasiWa);

    return res.json({ success: true, message: `Data absensi berhasil diarsipkan dan direset untuk ${namaArsip || 'Tahun Baru'}.` });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});
