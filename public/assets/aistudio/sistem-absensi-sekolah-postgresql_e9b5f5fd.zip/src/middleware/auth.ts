import { Request, Response, NextFunction } from 'express';
import { adminAuth } from '../lib/firebase-admin.ts';
import { DecodedIdToken } from 'firebase-admin/auth';
import { db } from '../db/index.ts';
import { sessions } from '../db/schema.ts';
import { eq, gt } from 'drizzle-orm';

export interface AuthUser {
  uid?: string;
  username?: string;
  identifier?: string;
  role: string;
  nama?: string;
  kelas?: string;
}

export interface AuthRequest extends Request {
  user?: AuthUser | DecodedIdToken;
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  const sessionTokenHeader = req.headers['x-session-token'] as string;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.split('Bearer ')[1]
    : sessionTokenHeader;

  if (!token) {
    return res.status(401).json({ success: false, message: 'Unauthorized: Missing token' });
  }

  // 1. Try PostgreSQL sessions table first (fastest for app logins)
  try {
    const now = new Date();
    const sessionList = await db
      .select()
      .from(sessions)
      .where(eq(sessions.token, token))
      .limit(1);

    if (sessionList.length > 0) {
      const sess = sessionList[0];
      if (sess.expiresAt > now) {
        req.user = {
          identifier: sess.identifier,
          username: sess.identifier,
          role: sess.role,
          nama: sess.nama || sess.identifier,
          kelas: sess.kelas || '',
        };
        return next();
      } else {
        return res.status(401).json({ success: false, message: 'Sesi berakhir. Silakan login ulang.' });
      }
    }
  } catch (err) {
    console.warn('Session query lookup error:', err);
  }

  // 2. Try Firebase ID Token
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = decodedToken;
    return next();
  } catch (error) {
    return res.status(401).json({ success: false, message: 'Token tidak valid atau tidak ditemukan.' });
  }
};

export const requireRole = (allowedRoles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    const userRole = (req.user as any)?.role || 'user';
    if (userRole === 'admin' || allowedRoles.includes(userRole)) {
      return next();
    }
    return res.status(403).json({ success: false, message: 'Akses Ditolak: Anda tidak memiliki izin.' });
  };
};
